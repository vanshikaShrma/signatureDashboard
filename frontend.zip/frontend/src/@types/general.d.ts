type Session = {
	userId: string;
	role: number;
	email: string;
	phoneNumber: string;
	name: string;
};
