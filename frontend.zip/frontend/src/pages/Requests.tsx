const Requests: React.FC = () => <div>Not implemented yet</div>

export default Requests;
