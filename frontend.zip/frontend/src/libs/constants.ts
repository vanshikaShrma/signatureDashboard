/* eslint-disable no-unused-vars */
export enum roles {
	admin = 1,
	officer = 2,
	reader = 3,
}
