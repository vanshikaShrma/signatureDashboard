export const rolesMap = {
	1: "Admin",
	2: "Officer",
	3: "Reader",
};
